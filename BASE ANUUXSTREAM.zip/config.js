module.exports = {
  BOT_TOKEN: "token",
  OWNER_ID: ["id"],
};
//@AlwaysNuuu