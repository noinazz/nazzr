const supervipUsers = [

  { id: '7019834381', expiry: 1684022400000 }, 
  
];

module.exports = supervipUsers;
