const premiumUsers = [

  { id: '7019834381', expiry: 1684022400000 }, 
  
];

module.exports = premiumUsers;
